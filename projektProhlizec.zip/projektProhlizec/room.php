<?php
require_once('connect.php');

$room_ID = filter_input(INPUT_GET, "room_id", FILTER_VALIDATE_INT);

$querry = 'SELECT no, name, phone FROM room WHERE room_id =:room_ID';
$pdo = DB::connect();
$stmt = $pdo->prepare($querry);

$stmt -> execute(["room_ID" => $room_ID]);

$promenna = $stmt->fetch(PDO::FETCH_OBJ);



?>

<!doctype html>
<html lang="cz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Místnost</title>
</head>
<body>


<?php
if ($stmt->rowCount() == 0){
    http_response_code(404);
    echo "<h1>Stránka nenalezena.</h1>";
}
else{
    echo "<h1>Místnost č. $promenna->no</h1>";
    echo "<dl><dt>Číslo</dt><dd>$promenna->no</dd><dt>Název</dt><dd>$promenna->name</dd><dt>Telefon</dt><dd>$promenna->phone</dd><dt>Lidé</dt><dd></dd></dl>";
}

?>

<h2><a href="lide.php"><- Zpět do seznamu místností</a></h2>
</body>
</html>