<?php
require_once('connect.php');

$querry = "SELECT e.employee_id 'id', CONCAT(e.surname, ' ', e.name) 'name', room.name 'room', room.phone, e.job FROM employee e INNER JOIN room ON e.room = room.room_id ORDER BY e.surname";

$pdo = DB::connect();
$stmt = $pdo->prepare($querry);

$stmt->execute();

$promenna = $stmt->fetch(PDO::FETCH_OBJ);

$html = "";

while ($promenna = $stmt->fetch(PDO::FETCH_OBJ)){
    $html .= "<tr><td><a href='./person.php?employee_id={$promenna->id}'>$promenna->name</a></td><td>$promenna->room</td><td>$promenna->phone</td><td>$promenna->job</td></tr>";

}

?>
<!doctype html>
<html lang="cz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Seznam zaměstnanců</title>
</head>
<body>
<h1>Seznam zaměsnanců</h1>

<table class='tabulka'><thead><tr><th>Jméno</th> <th>Místnost</th> <th>Telefon</th> <th>Pozice</th> </tr></thead>

<?= $html;

echo "<h2><a href='index.html'><- Zpět na hlavní stránku</a></h2>";
?>

</table>
</body>
</html>



