<?php
    require_once('connect.php');

    $querry = 'SELECT * FROM room';

    $pdo = DB::connect();
    $stmt = $pdo->prepare($querry);

    $stmt->execute();

    $promenna = $stmt->fetch(PDO::FETCH_OBJ);

    $html = "";

    while ($promenna = $stmt->fetch(PDO::FETCH_OBJ)){
        $html .= "<tr><td><a href='./room.php?room_id={$promenna->room_id}'>$promenna->name</a></td><td>$promenna->no</td><td>$promenna->phone</td></tr>";
    }

?>

<!doctype html>
<html lang="cz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Seznam místností</title>
</head>
<body>
    <h1>Seznam místností</h1>
    <table class='tabulka'><thead><tr><th>Název</th> <th>Číslo</th> <th>Telefon</th> </tr></thead>

    <?= $html

    ?>
    <h2><a href="index.html"><- Zpět na hlavní stránku</a> </h2>
    </table>
</body>
</html>


